export type Coordinate = {
  latitude: number;
  longitude: number;
};

export type RadarKind =
  | 'Velocidade'
  | 'Semáforo'
  | 'Faixa de pedestres'
  | 'Caminhões'
  | 'Conversão proibida';

export type Radar = {
  id: string;
  name: string;
  address: string;
  coordinate: Coordinate;
  limitKmh?: number;
  kinds: RadarKind[];
  direction?: string;
  cetId?: string;
  referenceOnly?: boolean;
};

export type LocationState = {
  coordinate: Coordinate | null;
  accuracy: number | null;
  loading: boolean;
  permissionDenied: boolean;
  error: string | null;
};

export type AlertSettings = {
  distanceMeters: number;
  voice: boolean;
  haptics: boolean;
};
