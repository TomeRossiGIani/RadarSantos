import type { Coordinate } from '../types';

const EARTH_RADIUS_METERS = 6371000;

const radians = (value: number) => (value * Math.PI) / 180;

export function distanceInMeters(from: Coordinate, to: Coordinate): number {
  const latitudeDelta = radians(to.latitude - from.latitude);
  const longitudeDelta = radians(to.longitude - from.longitude);
  const a =
    Math.sin(latitudeDelta / 2) * Math.sin(latitudeDelta / 2) +
    Math.cos(radians(from.latitude)) *
      Math.cos(radians(to.latitude)) *
      Math.sin(longitudeDelta / 2) *
      Math.sin(longitudeDelta / 2);

  return 2 * EARTH_RADIUS_METERS * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function formatDistance(distanceMeters: number): string {
  if (distanceMeters < 1000) {
    return String(Math.max(1, Math.round(distanceMeters))) + ' m';
  }

  return (distanceMeters / 1000).toFixed(1).replace('.', ',') + ' km';
}

export function formatKinds(kinds: string[]): string {
  return kinds.join(' · ');
}
