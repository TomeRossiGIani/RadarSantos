import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';

import { SANTOS_CENTER } from '../data/radaresSantos';
import type { Coordinate, Radar } from '../types';

type SantosMapProps = {
  radars: Radar[];
  currentPosition: Coordinate | null;
  selectedRadarId: string | null;
  followPosition: boolean;
  onRadarPress: (radarId: string) => void;
};

function createMapHtml(radars: Radar[]): string {
  const radarJson = JSON.stringify(radars).replace(/</g, '\\u003c');

  return [
    '<!doctype html>',
    '<html lang="pt-BR">',
    '<head>',
    '<meta charset="utf-8" />',
    '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />',
    '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />',
    '<style>',
    'html, body, #map { height: 100%; width: 100%; margin: 0; background: #10151f; }',
    '.leaflet-control-attribution { font: 9px Arial; background: rgba(15, 22, 32, 0.78) !important; color: #d9e6ff !important; }',
    '.leaflet-control-attribution a { color: #8ec5ff !important; }',
    '.radar-dot { width: 30px; height: 30px; border-radius: 15px; display:flex; align-items:center; justify-content:center; background:#ff644e; color:white; font-size:15px; border:3px solid rgba(255,255,255,0.9); box-shadow:0 3px 12px rgba(149,26,16,0.55); }',
    '.radar-dot.active { transform:scale(1.18); background:#ffd166; color:#1d2939; box-shadow:0 0 0 8px rgba(255,209,102,0.23); }',
    '.position-dot { width:18px; height:18px; border-radius:50%; background:#3d9bff; border:3px solid white; box-shadow:0 0 0 7px rgba(61,155,255,0.25); }',
    '.leaflet-popup-content-wrapper { border-radius: 12px; background: #18202c; color: #f5f8fc; }',
    '.leaflet-popup-tip { background: #18202c; }',
    '</style>',
    '</head>',
    '<body>',
    '<div id="map"></div>',
    '<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>',
    '<script>',
    'const defaultCenter = [' + SANTOS_CENTER.latitude + ', ' + SANTOS_CENTER.longitude + '];',
    'let radarData = ' + radarJson + ';',
    'let selectedRadarId = null;',
    'let radarLayer = null;',
    'let positionMarker = null;',
    'const map = L.map("map", { zoomControl: false }).setView(defaultCenter, 13);',
    'L.control.zoom({ position: "bottomright" }).addTo(map);',
    'L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "&copy; OpenStreetMap contributors" }).addTo(map);',
    'function sendToApp(data) { if (window.ReactNativeWebView) { window.ReactNativeWebView.postMessage(JSON.stringify(data)); } }',
    'function radarIcon(active) { return L.divIcon({ className: "", html: "<div class=\\"radar-dot " + (active ? "active" : "") + "\\">◉</div>", iconSize: [30, 30], iconAnchor: [15, 15] }); }',
    'function renderRadars() {',
    '  if (radarLayer) { radarLayer.clearLayers(); }',
    '  radarLayer = L.layerGroup().addTo(map);',
    '  radarData.forEach(function (radar) {',
    '    const marker = L.marker([radar.coordinate.latitude, radar.coordinate.longitude], { icon: radarIcon(radar.id === selectedRadarId) }).addTo(radarLayer);',
    '    const limit = radar.limitKmh ? "<br><b>Limite: " + radar.limitKmh + " km/h</b>" : "";',
    '    marker.bindPopup("<b>" + radar.name + "</b><br>" + radar.address + limit);',
    '    marker.on("click", function () { sendToApp({ type: "radarSelected", id: radar.id }); });',
    '  });',
    '}',
    'function updatePosition(position, follow) {',
    '  if (!position) { return; }',
    '  const latLng = [position.latitude, position.longitude];',
    '  if (positionMarker) { positionMarker.setLatLng(latLng); } else {',
    '    positionMarker = L.marker(latLng, { icon: L.divIcon({ className: "", html: "<div class=\\"position-dot\\"></div>", iconSize: [18,18], iconAnchor: [9,9] }) }).addTo(map);',
    '  }',
    '  if (follow) { map.flyTo(latLng, Math.max(map.getZoom(), 15), { duration: 0.7 }); }',
    '}',
    'window.updateRadarMap = function (payload) {',
    '  if (payload.radars) { radarData = payload.radars; }',
    '  if (Object.prototype.hasOwnProperty.call(payload, "selectedRadarId")) { selectedRadarId = payload.selectedRadarId; renderRadars(); }',
    '  if (payload.currentPosition) { updatePosition(payload.currentPosition, payload.followPosition); }',
    '  if (payload.focusRadarId) {',
    '    const radar = radarData.find(function (item) { return item.id === payload.focusRadarId; });',
    '    if (radar) { map.flyTo([radar.coordinate.latitude, radar.coordinate.longitude], 16, { duration: 0.55 }); }',
    '  }',
    '};',
    'renderRadars();',
    'sendToApp({ type: "mapReady" });',
    '</script>',
    '</body>',
    '</html>'
  ].join('\\n');
}

export function SantosMap({
  radars,
  currentPosition,
  selectedRadarId,
  followPosition,
  onRadarPress
}: SantosMapProps) {
  const webViewRef = useRef<WebView>(null);
  const [ready, setReady] = useState(false);
  const mapHtml = useMemo(() => createMapHtml(radars), [radars]);

  const send = useCallback(
    (payload: Record<string, unknown>) => {
      if (!ready) {
        return;
      }

      const serialized = JSON.stringify(payload).replace(/</g, '\\u003c');
      webViewRef.current?.injectJavaScript(
        'window.updateRadarMap && window.updateRadarMap(' + serialized + '); true;'
      );
    },
    [ready]
  );

  useEffect(() => {
    send({
      currentPosition,
      followPosition
    });
  }, [currentPosition, followPosition, send]);

  useEffect(() => {
    send({
      selectedRadarId,
      focusRadarId: selectedRadarId
    });
  }, [selectedRadarId, send]);

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef}
        originWhitelist={['*']}
        source={{ html: mapHtml }}
        javaScriptEnabled
        domStorageEnabled
        onMessage={(event) => {
          try {
            const message = JSON.parse(event.nativeEvent.data) as {
              type?: string;
              id?: string;
            };

            if (message.type === 'mapReady') {
              setReady(true);
            }

            if (message.type === 'radarSelected' && message.id) {
              onRadarPress(message.id);
            }
          } catch {
            // Mensagens inesperadas do WebView não afetam o app.
          }
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    overflow: 'hidden'
  }
});
