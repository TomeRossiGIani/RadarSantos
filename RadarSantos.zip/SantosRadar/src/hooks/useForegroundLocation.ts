import * as Location from 'expo-location';
import { useCallback, useEffect, useRef, useState } from 'react';

import type { LocationState } from '../types';

const initialState: LocationState = {
  coordinate: null,
  accuracy: null,
  loading: false,
  permissionDenied: false,
  error: null
};

export function useForegroundLocation() {
  const [state, setState] = useState<LocationState>(initialState);
  const subscriptionRef = useRef<Location.LocationSubscription | null>(null);

  const stop = useCallback(() => {
    subscriptionRef.current?.remove();
    subscriptionRef.current = null;
  }, []);

  const start = useCallback(async () => {
    setState((current) => ({
      ...current,
      loading: true,
      error: null,
      permissionDenied: false
    }));

    try {
      const permission = await Location.requestForegroundPermissionsAsync();

      if (permission.status !== Location.PermissionStatus.GRANTED) {
        setState((current) => ({
          ...current,
          loading: false,
          permissionDenied: true,
          error: 'Permita o acesso à localização para calcular as distâncias.'
        }));
        return;
      }

      const currentLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced
      });

      setState({
        coordinate: {
          latitude: currentLocation.coords.latitude,
          longitude: currentLocation.coords.longitude
        },
        accuracy: currentLocation.coords.accuracy,
        loading: false,
        permissionDenied: false,
        error: null
      });

      stop();
      subscriptionRef.current = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Balanced,
          distanceInterval: 10,
          timeInterval: 3000
        },
        (nextLocation) => {
          setState({
            coordinate: {
              latitude: nextLocation.coords.latitude,
              longitude: nextLocation.coords.longitude
            },
            accuracy: nextLocation.coords.accuracy,
            loading: false,
            permissionDenied: false,
            error: null
          });
        }
      );
    } catch {
      setState((current) => ({
        ...current,
        loading: false,
        error: 'Não foi possível obter a sua localização agora.'
      }));
    }
  }, [stop]);

  useEffect(() => stop, [stop]);

  return {
    ...state,
    start,
    stop
  };
}
