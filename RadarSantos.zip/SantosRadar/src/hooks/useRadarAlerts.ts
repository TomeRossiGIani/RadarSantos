import * as Haptics from 'expo-haptics';
import * as Speech from 'expo-speech';
import { useEffect, useMemo, useRef } from 'react';

import type { AlertSettings, Coordinate, Radar } from '../types';
import { distanceInMeters } from '../utils/distance';

export type NearestRadar = {
  radar: Radar;
  distanceMeters: number;
};

function getNearestRadar(
  position: Coordinate | null,
  radars: Radar[]
): NearestRadar | null {
  if (!position) {
    return null;
  }

  let nearest: NearestRadar | null = null;

  for (const radar of radars) {
    const distanceMeters = distanceInMeters(position, radar.coordinate);

    if (!nearest || distanceMeters < nearest.distanceMeters) {
      nearest = { radar, distanceMeters };
    }
  }

  return nearest;
}

export function useRadarAlerts({
  position,
  radars,
  settings,
  enabled
}: {
  position: Coordinate | null;
  radars: Radar[];
  settings: AlertSettings;
  enabled: boolean;
}) {
  const nearest = useMemo(
    () => getNearestRadar(position, radars),
    [position, radars]
  );
  const alertedRadarIds = useRef(new Set<string>());

  useEffect(() => {
    if (!enabled || !nearest) {
      return;
    }

    const { radar, distanceMeters } = nearest;
    const resetDistance = settings.distanceMeters + 250;

    if (distanceMeters > resetDistance) {
      alertedRadarIds.current.clear();
      return;
    }

    if (
      distanceMeters > settings.distanceMeters ||
      alertedRadarIds.current.has(radar.id)
    ) {
      return;
    }

    alertedRadarIds.current.add(radar.id);

    if (settings.haptics) {
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }

    if (settings.voice) {
      const limitText = radar.limitKmh
        ? ', limite de ' + radar.limitKmh + ' quilômetros por hora'
        : '';
      const distanceText = Math.max(1, Math.round(distanceMeters));
      Speech.stop();
      Speech.speak(
        'Atenção. Ponto de fiscalização em aproximadamente ' +
          distanceText +
          ' metros' +
          limitText +
          '.',
        {
          language: 'pt-BR',
          pitch: 1,
          rate: 0.92
        }
      );
    }
  }, [enabled, nearest, settings]);

  return nearest;
}
