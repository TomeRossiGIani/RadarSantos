import type { Coordinate, Radar } from '../types';

export const SANTOS_CENTER: Coordinate = {
  latitude: -23.9608,
  longitude: -46.3336
};

export const RADAR_SOURCE_URL = 'https://cetsantos.com.br/radares-2/';

/*
 * Lista baseada na página pública da CET-Santos, consultada em 28/09/2026.
 * As coordenadas são pontos de referência próximos aos endereços divulgados.
 * Antes de publicar ou depender do app em uma viagem, valide os pontos no site
 * oficial da CET-Santos e substitua os valores que forem atualizados.
 */
export const RADARS_SANTOS: Radar[] = [
  {
    id: 'martins-fontes-465',
    name: 'Curva da Sancap',
    address: 'Av. Martins Fontes, altura do nº 465',
    coordinate: { latitude: -23.9328, longitude: -46.3712 },
    limitKmh: 50,
    kinds: ['Velocidade'],
    direction: 'Dois sentidos',
    cetId: '9038 / 9039',
    referenceOnly: true
  },
  {
    id: 'sergio-matte-viaduto-santa',
    name: 'Viaduto da Santa',
    address: 'Av. Eng. Civ. Sérgio da Costa Matte, próximo ao Viaduto da Santa',
    coordinate: { latitude: -23.9475, longitude: -46.3746 },
    limitKmh: 40,
    kinds: ['Velocidade'],
    direction: 'Ponta da Praia → Centro',
    cetId: '9041',
    referenceOnly: true
  },
  {
    id: 'sergio-matte-manoel-tourinho',
    name: 'Monumento ao Trabalhador Portuário',
    address: 'Av. Eng. Civ. Sérgio da Costa Matte, próximo à Rua Manoel Tourinho',
    coordinate: { latitude: -23.9504, longitude: -46.3719 },
    limitKmh: 40,
    kinds: ['Velocidade'],
    direction: 'Centro → Ponta da Praia',
    cetId: '9040',
    referenceOnly: true
  },
  {
    id: 'pedro-toledo-nebias',
    name: 'Pedro de Toledo × Conselheiro Nébias',
    address: 'Rua Governador Pedro de Toledo x Av. Conselheiro Nébias',
    coordinate: { latitude: -23.9632, longitude: -46.3335 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    cetId: '9057',
    referenceOnly: true
  },
  {
    id: 'galeao-washington-luis',
    name: 'Galeão Carvalhal × Canal 3',
    address: 'Rua Galeão Carvalhal x Av. Washington Luís',
    coordinate: { latitude: -23.9789, longitude: -46.3252 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    cetId: '9058',
    referenceOnly: true
  },
  {
    id: 'jovino-fraccaroli',
    name: 'Jovino de Mello × João Fraccaroli',
    address: 'Av. Jovino de Mello x Rua João Fraccaroli',
    coordinate: { latitude: -23.9443, longitude: -46.3897 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9063',
    referenceOnly: true
  },
  {
    id: 'presidente-wilson-emissario',
    name: 'Emissário Submarino',
    address: 'Av. Presidente Wilson, próximo ao Emissário Submarino',
    coordinate: { latitude: -23.9692, longitude: -46.3552 },
    limitKmh: 50,
    kinds: ['Velocidade'],
    direction: 'Dois sentidos',
    cetId: '9046 / 9047',
    referenceOnly: true
  },
  {
    id: 'presidente-wilson-gonzaga',
    name: 'Galeria AD Moreira',
    address: 'Av. Presidente Wilson, entre R. Marcílio Dias e R. Quintino Bocaiúva',
    coordinate: { latitude: -23.9709, longitude: -46.3418 },
    limitKmh: 50,
    kinds: ['Velocidade'],
    direction: 'Dois sentidos',
    cetId: '9050 / 9051',
    referenceOnly: true
  },
  {
    id: 'vicente-carvalho-paz',
    name: 'Vicente de Carvalho × Rua da Paz',
    address: 'Av. Vicente de Carvalho, próximo à Rua da Paz',
    coordinate: { latitude: -23.9785, longitude: -46.3207 },
    limitKmh: 50,
    kinds: ['Velocidade'],
    direction: 'Dois sentidos',
    cetId: '9048 / 9049',
    referenceOnly: true
  },
  {
    id: 'glycerio-vidal-sion',
    name: 'Francisco Glycério × Vidal Sion',
    address: 'Av. General Francisco Glycério / Rua Vidal Sion',
    coordinate: { latitude: -23.9611, longitude: -46.3418 },
    limitKmh: 50,
    kinds: ['Velocidade'],
    direction: 'Ponta da Praia → José Menino',
    cetId: '9045',
    referenceOnly: true
  },
  {
    id: 'gercino-yara',
    name: 'Gercino Hugo Caparelli',
    address: 'R. Gercino Hugo Caparelli, próximo à R. Yara Nascimento Santini',
    coordinate: { latitude: -23.9478, longitude: -46.3892 },
    limitKmh: 40,
    kinds: ['Velocidade'],
    cetId: '9043',
    referenceOnly: true
  },
  {
    id: 'manuel-ferramenta-228',
    name: 'Eng. Manuel Ferramenta Jr.',
    address: 'Av. Eng. Manuel Ferramenta Jr., próximo ao nº 228',
    coordinate: { latitude: -23.9533, longitude: -46.3841 },
    limitKmh: 40,
    kinds: ['Velocidade'],
    direction: 'Dois sentidos',
    cetId: '9042',
    referenceOnly: true
  },
  {
    id: 'nova-cintra-descida',
    name: 'Descida do Morro Nova Cintra',
    address: 'Av. Pref. Dr. Antônio Manoel de Carvalho, descida do Morro Nova Cintra',
    coordinate: { latitude: -23.9513, longitude: -46.3554 },
    limitKmh: 30,
    kinds: ['Velocidade'],
    cetId: '9044',
    referenceOnly: true
  },
  {
    id: 'nilo-pecanha-nova-cintra',
    name: 'Nilo Peçanha, Nova Cintra',
    address: 'Av. Dr. Nilo Peçanha, próximo à Av. Pref. Dr. Antônio Manoel de Carvalho',
    coordinate: { latitude: -23.9532, longitude: -46.3547 },
    limitKmh: 40,
    kinds: ['Velocidade'],
    cetId: '9044',
    referenceOnly: true
  },
  {
    id: 'affonso-penna-palmares',
    name: 'Praça Palmares',
    address: 'Av. Affonso Penna, nº 170 / 176',
    coordinate: { latitude: -23.9782, longitude: -46.3269 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9055 / 9056',
    referenceOnly: true
  },
  {
    id: 'bernardino-joaquim-tavora',
    name: 'Bernardino de Campos × Joaquim Távora',
    address: 'Av. Bernardino de Campos x Rua Joaquim Távora',
    coordinate: { latitude: -23.9673, longitude: -46.3345 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres', 'Conversão proibida'],
    direction: 'Dois sentidos',
    cetId: '9053 / 9052',
    referenceOnly: true
  },
  {
    id: 'senador-feijo-rangel',
    name: 'Senador Feijó × Rangel Pestana',
    address: 'Av. Senador Feijó x Av. Rangel Pestana',
    coordinate: { latitude: -23.9508, longitude: -46.3374 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9059 / 9069',
    referenceOnly: true
  },
  {
    id: 'nossa-senhora-fatima-400',
    name: 'Nossa Senhora de Fátima, 400',
    address: 'Av. Nossa Senhora de Fátima, nº 400',
    coordinate: { latitude: -23.9397, longitude: -46.3756 },
    limitKmh: 40,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9060',
    referenceOnly: true
  },
  {
    id: 'martins-fontes-pio-xii',
    name: 'Martins Fontes × Pio XII',
    address: 'Av. Martins Fontes, próximo à Rua Pio XII',
    coordinate: { latitude: -23.9367, longitude: -46.3718 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Caminhões'],
    direction: 'Dois sentidos',
    cetId: '9061 / 9062',
    referenceOnly: true
  },
  {
    id: 'sergio-matte-iguatemy',
    name: 'Sérgio C. Matte, Praça Iguatemy',
    address: 'Av. Eng. Civ. Sérgio C. Matte, próximo à Praça Iguatemy Martins',
    coordinate: { latitude: -23.9518, longitude: -46.3727 },
    limitKmh: 60,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Ponta da Praia → Centro',
    cetId: '9065',
    referenceOnly: true
  },
  {
    id: 'bartholomeu-joaquim-montenegro',
    name: 'Bartholomeu de Gusmão × Cel. Montenegro',
    address: 'Av. Bartholomeu de Gusmão x Av. Cel. Joaquim Montenegro',
    coordinate: { latitude: -23.9911, longitude: -46.3113 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9067 / 9068',
    referenceOnly: true
  },
  {
    id: 'bartholomeu-gusmao-108',
    name: 'Bartholomeu de Gusmão, 108',
    address: 'Av. Bartholomeu de Gusmão, em frente ao nº 108',
    coordinate: { latitude: -23.9901, longitude: -46.3162 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9072 / 9073',
    referenceOnly: true
  },
  {
    id: 'waldemar-rangel',
    name: 'Waldemar Leão × Rangel Pestana',
    address: 'Av. Dr. Waldemar Leão x Av. Rangel Pestana',
    coordinate: { latitude: -23.9463, longitude: -46.3519 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9070 / 9071',
    referenceOnly: true
  },
  {
    id: 'glycerio-pinheiro-machado',
    name: 'Glycério × Sen. Pinheiro Machado',
    address: 'Av. Francisco Glycério x Av. Senador Pinheiro Machado',
    coordinate: { latitude: -23.9622, longitude: -46.3472 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres', 'Conversão proibida'],
    direction: 'Dois sentidos',
    cetId: '9074 / 9075',
    referenceOnly: true
  },
  {
    id: 'viaduto-paulo-gomes',
    name: 'Viaduto Paulo Gomes Barbosa',
    address: 'Acesso ao viaduto Paulo Gomes Barbosa, entrada da cidade',
    coordinate: { latitude: -23.9361, longitude: -46.3742 },
    limitKmh: 40,
    kinds: ['Velocidade', 'Caminhões'],
    cetId: '9076',
    referenceOnly: true
  },
  {
    id: 'presidente-wilson-pinheiro-machado',
    name: 'Presidente Wilson × Sen. Pinheiro Machado',
    address: 'Av. Presidente Wilson x Av. Senador Pinheiro Machado',
    coordinate: { latitude: -23.9694, longitude: -46.3495 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres'],
    direction: 'Dois sentidos',
    cetId: '9077 / 9078',
    referenceOnly: true
  },
  {
    id: 'bernardino-carvalho',
    name: 'Bernardino de Campos × Carvalho de Mendonça',
    address: 'Av. Bernardino de Campos x Rua Carvalho de Mendonça',
    coordinate: { latitude: -23.9688, longitude: -46.3346 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres', 'Conversão proibida'],
    direction: 'Dois sentidos',
    cetId: '9080 / 9081',
    referenceOnly: true
  },
  {
    id: 'joao-pessoa-senador-feijo',
    name: 'João Pessoa × Senador Feijó',
    address: 'Rua João Pessoa x Av. Senador Feijó',
    coordinate: { latitude: -23.9537, longitude: -46.3338 },
    limitKmh: 50,
    kinds: ['Velocidade', 'Semáforo', 'Faixa de pedestres', 'Caminhões'],
    cetId: '9083',
    referenceOnly: true
  },
  {
    id: 'eduardo-alves-186',
    name: 'Eduardo Alves, 186',
    address: 'Rua Eduardo Alves, próximo ao nº 186',
    coordinate: { latitude: -23.9453, longitude: -46.3916 },
    kinds: ['Caminhões'],
    cetId: '9082',
    referenceOnly: true
  }
];

export const DEMO_ROUTE: Coordinate[] = [
  { latitude: -23.9700, longitude: -46.3572 },
  { latitude: -23.9698, longitude: -46.3558 },
  { latitude: -23.9695, longitude: -46.3543 },
  { latitude: -23.9694, longitude: -46.3528 },
  { latitude: -23.9694, longitude: -46.3513 },
  { latitude: -23.9694, longitude: -46.3501 },
  { latitude: -23.9694, longitude: -46.3495 },
  { latitude: -23.9695, longitude: -46.3485 },
  { latitude: -23.9697, longitude: -46.3475 }
];
