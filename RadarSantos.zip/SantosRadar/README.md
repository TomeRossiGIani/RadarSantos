# RadarSantos

Aplicativo Android pessoal para visualizar pontos de fiscalização eletrônica em
Santos/SP, medir a distância pelo GPS e emitir alertas de aproximação.

## O que já está pronto

- Mapa de Santos usando OpenStreetMap, sem chave paga.
- 28 pontos da relação pública de radares ativos da CET-Santos.
- Localização em tempo real enquanto o app está aberto.
- Distância até o ponto de fiscalização mais próximo.
- Alertas configuráveis por voz e vibração a 250 m, 500 m ou 1 km.
- Lista de todos os pontos e foco individual no mapa.
- Rota simulada na orla para testar os alertas sem dirigir.
- Configuração EAS para gerar um APK instalável.

## Rodar no celular

1. Instale Node.js LTS no computador.
2. Abra esta pasta no terminal.
3. Execute:

    npm install
    npx expo start

4. Instale o aplicativo Expo Go no Android.
5. Escaneie o QR code exibido no terminal.

No aplicativo, toque em Meu local e permita a localização. Para uma
demonstração sem GPS, toque em Simular rota.

## Gerar o APK

Com uma conta gratuita no Expo/EAS:

    npm install -g eas-cli
    eas login
    eas build --platform android --profile preview

Ao fim, o EAS fornece um link para baixar o APK. O perfil preview já está
configurado para APK, não para AAB da Play Store.

## APK automático no GitHub

O repositório inclui um fluxo do GitHub Actions que gera automaticamente um APK
de teste quando o projeto é enviado para a branch main. Ao terminar, ele publica
o arquivo app-debug.apk na área Releases do repositório.

## Dados e segurança

A lista de endereços foi baseada na página pública da CET-Santos, consultada em
28/09/2026:

https://cetsantos.com.br/radares-2/

Os endereços e categorias são da fonte pública. As coordenadas incluídas nesta
demo são pontos de referência próximos a cada endereço e precisam ser
revalidadas antes de qualquer publicação ou uso crítico, pois equipamentos,
limites e regras podem mudar. Siga a sinalização da via e use o app para
respeitar os limites de velocidade.

## Onde atualizar os radares

Edite o arquivo:

    src/data/radaresSantos.ts

Cada item possui nome, endereço, coordenada, limite, categorias e código da
CET-Santos. Assim, dá para atualizar os dados sem mexer na interface, no mapa
ou no mecanismo de alertas.
