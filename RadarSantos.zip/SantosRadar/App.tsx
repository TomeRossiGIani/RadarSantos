import { StatusBar } from 'expo-status-bar';
import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  FlatList,
  Linking,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View
} from 'react-native';

import { SantosMap } from './src/components/SantosMap';
import {
  DEMO_ROUTE,
  RADARS_SANTOS,
  RADAR_SOURCE_URL
} from './src/data/radaresSantos';
import { useForegroundLocation } from './src/hooks/useForegroundLocation';
import { useRadarAlerts } from './src/hooks/useRadarAlerts';
import type { AlertSettings, Coordinate, Radar } from './src/types';
import { distanceInMeters, formatDistance, formatKinds } from './src/utils/distance';

const DEFAULT_SETTINGS: AlertSettings = {
  distanceMeters: 500,
  voice: true,
  haptics: true
};

type RadarRow = {
  radar: Radar;
  distanceMeters: number | null;
};

function ToolButton({
  icon,
  label,
  onPress
}: {
  icon: string;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [
        styles.toolButton,
        pressed && styles.pressed
      ]}
    >
      <Text style={styles.toolIcon}>{icon}</Text>
    </Pressable>
  );
}

function RadarCard({
  radar,
  distanceMeters,
  label
}: {
  radar: Radar;
  distanceMeters: number | null;
  label: string;
}) {
  const limit = radar.limitKmh ? String(radar.limitKmh) + ' km/h' : 'Fiscalização';

  return (
    <View style={styles.radarCard}>
      <View style={styles.cardHeading}>
        <View>
          <Text style={styles.kicker}>{label}</Text>
          <Text numberOfLines={1} style={styles.radarName}>
            {radar.name}
          </Text>
        </View>
        <View style={styles.distancePill}>
          <Text style={styles.distanceValue}>
            {distanceMeters === null ? '—' : formatDistance(distanceMeters)}
          </Text>
        </View>
      </View>
      <Text numberOfLines={1} style={styles.address}>
        {radar.address}
      </Text>
      <View style={styles.tags}>
        <View style={styles.limitTag}>
          <Text style={styles.limitTagText}>{limit}</Text>
        </View>
        <Text numberOfLines={1} style={styles.kindText}>
          {formatKinds(radar.kinds)}
        </Text>
      </View>
    </View>
  );
}

export default function App() {
  const location = useForegroundLocation();
  const [settings, setSettings] = useState<AlertSettings>(DEFAULT_SETTINGS);
  const [alertsEnabled, setAlertsEnabled] = useState(false);
  const [demoEnabled, setDemoEnabled] = useState(false);
  const [demoIndex, setDemoIndex] = useState(0);
  const [followPosition, setFollowPosition] = useState(false);
  const [selectedRadarId, setSelectedRadarId] = useState<string | null>(null);
  const [listOpen, setListOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const simulationPosition: Coordinate =
    DEMO_ROUTE[demoIndex] ?? DEMO_ROUTE[0] ?? {
      latitude: -23.9694,
      longitude: -46.3495
    };
  const activePosition = demoEnabled
    ? simulationPosition
    : location.coordinate;

  const nearest = useRadarAlerts({
    position: activePosition,
    radars: RADARS_SANTOS,
    settings,
    enabled: alertsEnabled
  });

  useEffect(() => {
    if (!demoEnabled) {
      return;
    }

    setDemoIndex(0);
    const timer = setInterval(() => {
      setDemoIndex((current) => (current + 1) % DEMO_ROUTE.length);
    }, 1800);

    return () => clearInterval(timer);
  }, [demoEnabled]);

  const radarRows = useMemo<RadarRow[]>(() => {
    return RADARS_SANTOS.map((radar) => ({
      radar,
      distanceMeters: activePosition
        ? distanceInMeters(activePosition, radar.coordinate)
        : null
    })).sort((left, right) => {
      if (left.distanceMeters === null && right.distanceMeters === null) {
        return left.radar.name.localeCompare(right.radar.name);
      }

      if (left.distanceMeters === null) {
        return 1;
      }

      if (right.distanceMeters === null) {
        return -1;
      }

      return left.distanceMeters - right.distanceMeters;
    });
  }, [activePosition]);

  const selectedRadar =
    RADARS_SANTOS.find((radar) => radar.id === selectedRadarId) ?? null;
  const selectedRow =
    radarRows.find((row) => row.radar.id === selectedRadar?.id) ?? null;
  const featuredRadar = selectedRadar ?? nearest?.radar ?? null;
  const featuredDistance = selectedRadar
    ? selectedRow?.distanceMeters ?? null
    : nearest?.distanceMeters ?? null;

  const useMyPosition = () => {
    setDemoEnabled(false);
    setFollowPosition(true);
    void location.start();
  };

  const toggleDemo = () => {
    const nextValue = !demoEnabled;
    setDemoEnabled(nextValue);
    setFollowPosition(nextValue);

    if (nextValue) {
      setAlertsEnabled(true);
      setSelectedRadarId(null);
      return;
    }

    void location.start();
  };

  const toggleAlerts = () => {
    const nextValue = !alertsEnabled;
    setAlertsEnabled(nextValue);

    if (nextValue && !demoEnabled) {
      void location.start();
    }
  };

  const selectRadar = (radarId: string) => {
    setSelectedRadarId(radarId);
    setFollowPosition(false);
    setListOpen(false);
  };

  const resetMap = () => {
    setSelectedRadarId(null);
    setFollowPosition(true);

    if (!demoEnabled) {
      void location.start();
    }
  };

  const openOfficialSource = () => {
    void Linking.openURL(RADAR_SOURCE_URL);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />

      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>RadarSantos</Text>
          <Text style={styles.subBrand}>SANTOS / SP · DEMO PESSOAL</Text>
        </View>
        <View style={[styles.liveBadge, demoEnabled && styles.demoBadge]}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>
            {demoEnabled ? 'SIMULANDO' : 'GPS'}
          </Text>
        </View>
      </View>

      <View style={styles.mapWrap}>
        <SantosMap
          radars={RADARS_SANTOS}
          currentPosition={activePosition}
          selectedRadarId={selectedRadarId}
          followPosition={followPosition}
          onRadarPress={selectRadar}
        />

        <View style={styles.mapTools}>
          <ToolButton icon="⌖" label="Centralizar no meu local" onPress={resetMap} />
          <ToolButton
            icon="☷"
            label="Abrir todos os radares"
            onPress={() => setListOpen(true)}
          />
          <ToolButton
            icon="⚙"
            label="Abrir ajustes"
            onPress={() => setSettingsOpen(true)}
          />
        </View>

        {location.error && !demoEnabled ? (
          <Pressable onPress={useMyPosition} style={styles.locationPrompt}>
            <Text style={styles.locationPromptText}>{location.error}</Text>
            <Text style={styles.locationPromptAction}>Tentar novamente</Text>
          </Pressable>
        ) : null}
      </View>

      <View style={styles.bottomPanel}>
        <View style={styles.modeRow}>
          <View style={styles.modeTextWrap}>
            <Text style={styles.modeLabel}>
              {demoEnabled ? 'MODO DEMONSTRAÇÃO' : 'MONITORAMENTO'}
            </Text>
            <Text style={styles.modeDescription}>
              {demoEnabled
                ? 'Rota simulada pela orla para testar alertas.'
                : activePosition
                  ? 'Localização atual sendo atualizada.'
                  : 'Ative a localização para medir as distâncias.'}
            </Text>
          </View>
          <Switch
            value={alertsEnabled}
            onValueChange={toggleAlerts}
            trackColor={{ false: '#344154', true: '#1e7f69' }}
            thumbColor={alertsEnabled ? '#f4fff9' : '#b9c1cc'}
          />
        </View>

        {featuredRadar ? (
          <RadarCard
            radar={featuredRadar}
            distanceMeters={featuredDistance}
            label={selectedRadar ? 'PONTO SELECIONADO' : 'MAIS PRÓXIMO'}
          />
        ) : (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>Localize-se para começar</Text>
            <Text style={styles.emptyCopy}>
              O mapa já mostra os radares ativos de Santos. Libere o GPS para
              receber distância e alertas.
            </Text>
          </View>
        )}

        <View style={styles.actionRow}>
          <Pressable
            onPress={toggleDemo}
            style={({ pressed }) => [
              styles.secondaryButton,
              demoEnabled && styles.secondaryButtonActive,
              pressed && styles.pressed
            ]}
          >
            <Text style={styles.secondaryButtonText}>
              {demoEnabled ? 'Parar demo' : 'Simular rota'}
            </Text>
          </Pressable>
          <Pressable
            onPress={useMyPosition}
            style={({ pressed }) => [
              styles.primaryButton,
              pressed && styles.pressed
            ]}
          >
            <Text style={styles.primaryButtonText}>
              {location.loading ? 'Localizando…' : 'Meu local'}
            </Text>
          </Pressable>
        </View>

        <Pressable onPress={openOfficialSource} style={styles.sourceButton}>
          <Text style={styles.sourceText}>
            Dados de referência: CET-Santos · conferir antes de dirigir
          </Text>
        </Pressable>
      </View>

      <Modal
        animationType="slide"
        transparent
        visible={listOpen}
        onRequestClose={() => setListOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalSheet}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Radares em Santos</Text>
                <Text style={styles.modalSubtitle}>
                  {RADARS_SANTOS.length} pontos ativos na fonte consultada
                </Text>
              </View>
              <Pressable
                accessibilityLabel="Fechar lista de radares"
                onPress={() => setListOpen(false)}
                style={styles.closeButton}
              >
                <Text style={styles.closeText}>×</Text>
              </Pressable>
            </View>
            <FlatList
              data={radarRows}
              keyExtractor={(item) => item.radar.id}
              contentContainerStyle={styles.radarList}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => selectRadar(item.radar.id)}
                  style={({ pressed }) => [
                    styles.listRow,
                    item.radar.id === selectedRadarId && styles.listRowSelected,
                    pressed && styles.pressed
                  ]}
                >
                  <View style={styles.listIcon}>
                    <Text style={styles.listIconText}>◉</Text>
                  </View>
                  <View style={styles.listContent}>
                    <Text numberOfLines={1} style={styles.listTitle}>
                      {item.radar.name}
                    </Text>
                    <Text numberOfLines={1} style={styles.listAddress}>
                      {item.radar.address}
                    </Text>
                    <Text numberOfLines={1} style={styles.listKinds}>
                      {formatKinds(item.radar.kinds)}
                    </Text>
                  </View>
                  <View style={styles.listDistance}>
                    <Text style={styles.listDistanceText}>
                      {item.distanceMeters === null
                        ? 'Ver'
                        : formatDistance(item.distanceMeters)}
                    </Text>
                    {item.radar.limitKmh ? (
                      <Text style={styles.listLimit}>
                        {item.radar.limitKmh} km/h
                      </Text>
                    ) : null}
                  </View>
                </Pressable>
              )}
            />
            <Pressable onPress={openOfficialSource} style={styles.modalSource}>
              <Text style={styles.modalSourceText}>Abrir lista oficial da CET-Santos</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal
        animationType="fade"
        transparent
        visible={settingsOpen}
        onRequestClose={() => setSettingsOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalSheet, styles.settingsSheet]}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Ajustes de alerta</Text>
                <Text style={styles.modalSubtitle}>
                  Somente enquanto o app estiver aberto
                </Text>
              </View>
              <Pressable
                accessibilityLabel="Fechar ajustes"
                onPress={() => setSettingsOpen(false)}
                style={styles.closeButton}
              >
                <Text style={styles.closeText}>×</Text>
              </Pressable>
            </View>

            <ScrollView contentContainerStyle={styles.settingsContent}>
              <Text style={styles.settingLabel}>Avisar quando faltar</Text>
              <View style={styles.distanceChoices}>
                {[250, 500, 1000].map((value) => (
                  <Pressable
                    key={value}
                    onPress={() =>
                      setSettings((current) => ({
                        ...current,
                        distanceMeters: value
                      }))
                    }
                    style={[
                      styles.distanceChoice,
                      settings.distanceMeters === value &&
                        styles.distanceChoiceSelected
                    ]}
                  >
                    <Text
                      style={[
                        styles.distanceChoiceText,
                        settings.distanceMeters === value &&
                          styles.distanceChoiceTextSelected
                      ]}
                    >
                      {value < 1000 ? value + ' m' : '1 km'}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <View style={styles.settingRow}>
                <View>
                  <Text style={styles.settingTitle}>Aviso por voz</Text>
                  <Text style={styles.settingDescription}>
                    Fala a distância e o limite de velocidade.
                  </Text>
                </View>
                <Switch
                  value={settings.voice}
                  onValueChange={(voice) =>
                    setSettings((current) => ({ ...current, voice }))
                  }
                  trackColor={{ false: '#344154', true: '#1e7f69' }}
                  thumbColor={settings.voice ? '#f4fff9' : '#b9c1cc'}
                />
              </View>

              <View style={styles.settingRow}>
                <View>
                  <Text style={styles.settingTitle}>Vibração</Text>
                  <Text style={styles.settingDescription}>
                    Vibra junto com o aviso de proximidade.
                  </Text>
                </View>
                <Switch
                  value={settings.haptics}
                  onValueChange={(haptics) =>
                    setSettings((current) => ({ ...current, haptics }))
                  }
                  trackColor={{ false: '#344154', true: '#1e7f69' }}
                  thumbColor={settings.haptics ? '#f4fff9' : '#b9c1cc'}
                />
              </View>

              <View style={styles.disclaimer}>
                <Text style={styles.disclaimerTitle}>Use responsável</Text>
                <Text style={styles.disclaimerText}>
                  O app é uma referência de segurança para respeitar os limites.
                  Pontos e regras de trânsito podem mudar: confira sempre a
                  sinalização e a CET-Santos.
                </Text>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0d121a'
  },
  header: {
    alignItems: 'center',
    backgroundColor: '#0d121a',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14
  },
  brand: {
    color: '#f5f7fa',
    fontSize: 23,
    fontWeight: '800',
    letterSpacing: -0.4
  },
  subBrand: {
    color: '#8fa0b4',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.1,
    marginTop: 2
  },
  liveBadge: {
    alignItems: 'center',
    backgroundColor: '#18262c',
    borderColor: '#2c7164',
    borderRadius: 30,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 7
  },
  demoBadge: {
    backgroundColor: '#2b2116',
    borderColor: '#8e6630'
  },
  liveDot: {
    backgroundColor: '#52d297',
    borderRadius: 4,
    height: 7,
    width: 7
  },
  liveText: {
    color: '#d8f7e8',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8
  },
  mapWrap: {
    flex: 1,
    minHeight: 220,
    overflow: 'hidden',
    position: 'relative'
  },
  mapTools: {
    gap: 9,
    position: 'absolute',
    right: 14,
    top: 14
  },
  toolButton: {
    alignItems: 'center',
    backgroundColor: '#172130',
    borderColor: '#31445b',
    borderRadius: 13,
    borderWidth: 1,
    elevation: 4,
    height: 45,
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.28,
    shadowRadius: 6,
    width: 45
  },
  toolIcon: {
    color: '#edf5ff',
    fontSize: 22,
    fontWeight: '700'
  },
  locationPrompt: {
    backgroundColor: 'rgba(18, 27, 39, 0.94)',
    borderColor: '#ca9045',
    borderRadius: 12,
    borderWidth: 1,
    bottom: 14,
    left: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    position: 'absolute',
    right: 72
  },
  locationPromptText: {
    color: '#e8edf3',
    fontSize: 12,
    lineHeight: 17
  },
  locationPromptAction: {
    color: '#ffcb7b',
    fontSize: 12,
    fontWeight: '800',
    marginTop: 4
  },
  bottomPanel: {
    backgroundColor: '#0d121a',
    paddingBottom: 12,
    paddingHorizontal: 16,
    paddingTop: 13
  },
  modeRow: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12
  },
  modeTextWrap: {
    flex: 1,
    paddingRight: 12
  },
  modeLabel: {
    color: '#c5d5e8',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1
  },
  modeDescription: {
    color: '#7e90a6',
    fontSize: 12,
    marginTop: 3
  },
  radarCard: {
    backgroundColor: '#16202e',
    borderColor: '#2e4055',
    borderRadius: 16,
    borderWidth: 1,
    padding: 14
  },
  cardHeading: {
    alignItems: 'flex-start',
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  kicker: {
    color: '#80b9ff',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1,
    marginBottom: 4
  },
  radarName: {
    color: '#f2f6fb',
    fontSize: 17,
    fontWeight: '800',
    maxWidth: 220
  },
  distancePill: {
    backgroundColor: '#264f80',
    borderRadius: 9,
    marginLeft: 8,
    paddingHorizontal: 8,
    paddingVertical: 6
  },
  distanceValue: {
    color: '#eaf4ff',
    fontSize: 14,
    fontWeight: '800'
  },
  address: {
    color: '#9dafc2',
    fontSize: 12,
    marginTop: 6
  },
  tags: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 8,
    marginTop: 11
  },
  limitTag: {
    backgroundColor: '#344e70',
    borderRadius: 7,
    paddingHorizontal: 8,
    paddingVertical: 4
  },
  limitTagText: {
    color: '#e7f0ff',
    fontSize: 10,
    fontWeight: '800'
  },
  kindText: {
    color: '#7f93aa',
    flex: 1,
    fontSize: 11
  },
  emptyCard: {
    backgroundColor: '#16202e',
    borderColor: '#2e4055',
    borderRadius: 16,
    borderWidth: 1,
    padding: 15
  },
  emptyTitle: {
    color: '#f2f6fb',
    fontSize: 16,
    fontWeight: '800'
  },
  emptyCopy: {
    color: '#9dafc2',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 5
  },
  actionRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 11
  },
  primaryButton: {
    alignItems: 'center',
    backgroundColor: '#3482dc',
    borderRadius: 12,
    flex: 1,
    justifyContent: 'center',
    minHeight: 46
  },
  primaryButtonText: {
    color: '#f6fbff',
    fontSize: 13,
    fontWeight: '800'
  },
  secondaryButton: {
    alignItems: 'center',
    backgroundColor: '#1c2938',
    borderColor: '#364b63',
    borderRadius: 12,
    borderWidth: 1,
    flex: 1,
    justifyContent: 'center',
    minHeight: 46
  },
  secondaryButtonActive: {
    backgroundColor: '#2b261d',
    borderColor: '#8b6a37'
  },
  secondaryButtonText: {
    color: '#dbe7f5',
    fontSize: 13,
    fontWeight: '800'
  },
  pressed: {
    opacity: 0.72
  },
  sourceButton: {
    alignItems: 'center',
    marginTop: 10,
    paddingVertical: 2
  },
  sourceText: {
    color: '#7891ad',
    fontSize: 10,
    textDecorationLine: 'underline'
  },
  modalBackdrop: {
    backgroundColor: 'rgba(0, 0, 0, 0.62)',
    flex: 1,
    justifyContent: 'flex-end'
  },
  modalSheet: {
    backgroundColor: '#111924',
    borderColor: '#314257',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    maxHeight: '85%',
    minHeight: '48%',
    overflow: 'hidden'
  },
  settingsSheet: {
    minHeight: undefined
  },
  modalHeader: {
    alignItems: 'center',
    borderBottomColor: '#263649',
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 17
  },
  modalTitle: {
    color: '#f4f8fc',
    fontSize: 19,
    fontWeight: '800'
  },
  modalSubtitle: {
    color: '#8194aa',
    fontSize: 11,
    marginTop: 3
  },
  closeButton: {
    alignItems: 'center',
    backgroundColor: '#233143',
    borderRadius: 16,
    height: 32,
    justifyContent: 'center',
    width: 32
  },
  closeText: {
    color: '#deebfa',
    fontSize: 25,
    fontWeight: '300',
    lineHeight: 27
  },
  radarList: {
    paddingBottom: 12
  },
  listRow: {
    alignItems: 'center',
    borderBottomColor: '#213044',
    borderBottomWidth: 1,
    flexDirection: 'row',
    paddingHorizontal: 18,
    paddingVertical: 13
  },
  listRowSelected: {
    backgroundColor: '#172b42'
  },
  listIcon: {
    alignItems: 'center',
    backgroundColor: '#7f3c35',
    borderRadius: 14,
    height: 29,
    justifyContent: 'center',
    marginRight: 10,
    width: 29
  },
  listIconText: {
    color: '#ffddd8',
    fontSize: 14
  },
  listContent: {
    flex: 1,
    paddingRight: 8
  },
  listTitle: {
    color: '#edf4fc',
    fontSize: 14,
    fontWeight: '800'
  },
  listAddress: {
    color: '#94a8bf',
    fontSize: 11,
    marginTop: 2
  },
  listKinds: {
    color: '#647a92',
    fontSize: 10,
    marginTop: 4
  },
  listDistance: {
    alignItems: 'flex-end'
  },
  listDistanceText: {
    color: '#b7d8ff',
    fontSize: 13,
    fontWeight: '800'
  },
  listLimit: {
    color: '#7891ab',
    fontSize: 10,
    marginTop: 3
  },
  modalSource: {
    alignItems: 'center',
    borderTopColor: '#263649',
    borderTopWidth: 1,
    padding: 15
  },
  modalSourceText: {
    color: '#92c5ff',
    fontSize: 12,
    fontWeight: '800'
  },
  settingsContent: {
    padding: 20
  },
  settingLabel: {
    color: '#d9e5f2',
    fontSize: 13,
    fontWeight: '800',
    marginBottom: 10
  },
  distanceChoices: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 20
  },
  distanceChoice: {
    alignItems: 'center',
    backgroundColor: '#202d3d',
    borderColor: '#394d64',
    borderRadius: 10,
    borderWidth: 1,
    flex: 1,
    paddingVertical: 11
  },
  distanceChoiceSelected: {
    backgroundColor: '#1e4e7e',
    borderColor: '#66acff'
  },
  distanceChoiceText: {
    color: '#b7c8da',
    fontSize: 12,
    fontWeight: '800'
  },
  distanceChoiceTextSelected: {
    color: '#eff7ff'
  },
  settingRow: {
    alignItems: 'center',
    borderTopColor: '#263649',
    borderTopWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 16
  },
  settingTitle: {
    color: '#e7eef7',
    fontSize: 14,
    fontWeight: '700'
  },
  settingDescription: {
    color: '#8295ab',
    fontSize: 11,
    marginTop: 3,
    maxWidth: 240
  },
  disclaimer: {
    backgroundColor: '#2b251c',
    borderColor: '#735c32',
    borderRadius: 13,
    borderWidth: 1,
    marginTop: 5,
    padding: 13
  },
  disclaimerTitle: {
    color: '#ffd995',
    fontSize: 12,
    fontWeight: '800'
  },
  disclaimerText: {
    color: '#d4c6a8',
    fontSize: 11,
    lineHeight: 16,
    marginTop: 4
  }
});
